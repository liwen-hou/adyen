<div class="py-5 text-center">
  <img class="d-block mx-auto mb-4" src="img/adyen.png" alt="" width="72" height="72">
  <h2><font color="#f8f9fa">Marketplace DEMO</font></h2>
  <h5><font color="#f8f9fa">Powered by Adyen for Platforms</font></h4>
</div>
