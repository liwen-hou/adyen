<footer class="my-5 pt-5 text-muted text-center text-small">
  <p class="mb-1"><font color="white">&copy; 2020 Adyen for Platforms Demo</font></p>
</footer>
